# Meetwoyou 2.0

A premium social platform rebuilt as **pure HTML + CSS + vanilla JS** with a modular
architecture, PWA support, offline fallbacks, and a first-class admin panel.

- No build step (works from any static host, GitHub Pages, Firebase Hosting, etc.)
- Firebase (Auth, Firestore, Storage) and Cloudinary preserved from the legacy project
- Dark / Light themes, mobile-first responsive layout, accessibility baked in
- Installable PWA with offline shell and background push notifications

## Quick start

```bash
# Any static server will do — nothing to compile.
python3 -m http.server 8080
# or
npx serve .
```

Open http://localhost:8080

## Deployment

### GitHub Pages
1. Push this folder to a repo.
2. In **Settings → Pages** pick the branch and `/root`.
3. Optionally customise `env.js` with your own Firebase/Cloudinary keys.

### Firebase Hosting
```bash
firebase init hosting   # public dir: . (project root)
firebase deploy
```

## Configuration

Everything is centralised in [`js/services/config.js`](js/services/config.js) and can
be overridden at runtime through `env.js` (see `.env.example`). No credentials are
required in code — the existing production Firebase / Cloudinary values are used by
default so the app keeps working out of the box.

## Folder structure

```
/                     index.html, manifest, service worker, env.js
/assets/icons         PWA + favicon icons (preserved from legacy)
/css                  tokens.css • base.css • components.css • main.css (entry)
/js
  main.js             App entry — routes, chrome, service worker
  /utils              dom, router, theme, i18n
  /services           config, firebase, cloudinary, storage, notification, auth
  /components         navbar, modal, cards, buttons, badge
  /modules            home, search, messenger, create, profile, settings,
                      payment, admin, creator, auth
/pages                offline.html and future static shells
/docs                 changelog, backend compatibility report, deployment guide
```

## Feature map

| Area          | Status | Notes |
|---------------|--------|-------|
| Auth          | ✅     | Firebase Auth email/password + password reset |
| Home feed     | ✅     | Firestore `activity` collection with cache |
| Messenger     | ✅     | Realtime Firestore `chats/{id}/messages` |
| Create post   | ✅     | Cloudinary unsigned upload → Firestore |
| Profile       | ✅     | Session-backed, verified badge |
| Settings      | ✅     | 9 sections, no empty pages |
| Payments      | ✅     | Payout methods, transactions, CSV export |
| Admin         | ✅     | 8 tabs, live metrics, moderation, verification |
| PWA / offline | ✅     | Installable, offline shell, push scaffold |
| Dark/Light    | ✅     | Persisted, system-aware |

## Admin access

Admin status is controlled by email (persisted in `localStorage` under
`mw:auth:adminEmails`). The default seed is `admin@meetwoyou.com`. Register or
log in with that email, or open the browser console once and run:

```js
JSON.parse(localStorage.getItem('mw:auth:adminEmails'))
```

Add your email through **Admin → Settings → Admins** once you have access.

## Docs

- [Changelog](docs/CHANGELOG.md)
- [Backend compatibility report](docs/BACKEND_COMPATIBILITY.md)
- [Deployment guide](docs/DEPLOYMENT.md)
- [Optimization report](docs/OPTIMIZATION.md)
- [Bug report](docs/BUGS.md)
