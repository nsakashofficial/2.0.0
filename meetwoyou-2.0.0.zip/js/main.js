import { route, setNotFound, start, navigate } from './utils/router.js';
import { applyTheme } from './utils/theme.js';
import { init as initAuth, onSession, getSession } from './services/auth.js';
import { navbar, tabbar } from './components/navbar.js';
import { h } from './utils/dom.js';
import { toast } from './services/notification.js';

// --- Theme ---
applyTheme();

// --- Routes (lazy-loaded modules) ---
route('/',           () => import('./modules/home.js'));
route('/search',     () => import('./modules/search.js'));
route('/messenger',  () => import('./modules/messenger.js'));
route('/create',     () => import('./modules/create.js'));
route('/profile',    () => import('./modules/profile.js'));
route('/settings',   () => import('./modules/settings.js'));
route('/payments',   () => import('./modules/payment.js'));
route('/creator',    () => import('./modules/creator.js'));
route('/admin',      () => import('./modules/admin.js'));
route('/auth',       () => import('./modules/auth.js'));
setNotFound(() => Promise.resolve({ default: () => h('div', { class: 'mw-container' }, h('div', { class: 'mw-empty' }, h('h2', {}, '404'), h('p', {}, 'Page not found'))) }));

// --- Shell ---
const shell = document.getElementById('shell');
const navMount = document.createElement('div'); shell.appendChild(navMount);
const app = document.createElement('main'); app.id = 'app'; shell.appendChild(app);
const tabMount = document.createElement('div'); shell.appendChild(tabMount);

function paintChrome() {
  const user = getSession();
  navMount.replaceChildren(navbar({ user }));
  tabMount.replaceChildren(tabbar());
}

// --- Auth boot ---
initAuth().then(() => paintChrome());
onSession(() => paintChrome());

// --- Router boot ---
start('#app');

// --- Online/offline UX ---
addEventListener('offline', () => toast('You are offline — showing cached content', { type: 'info' }));
addEventListener('online', () => toast('Back online', { type: 'success' }));

// --- Service worker registration ---
if ('serviceWorker' in navigator && location.protocol !== 'file:') {
  addEventListener('load', () => {
    navigator.serviceWorker.register('./service-worker.js').catch(err => console.warn('SW', err));
  });
}

// --- Global keyboard shortcuts ---
addEventListener('keydown', (e) => {
  if (e.key === '/' && !/^(input|textarea|select)$/i.test(document.activeElement?.tagName)) {
    e.preventDefault(); navigate('/search');
  }
});
