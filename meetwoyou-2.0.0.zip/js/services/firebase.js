/**
 * Firebase service — thin wrapper around the modular v10 SDK loaded from the
 * gstatic CDN so we stay pure HTML/CSS/JS with no build step. Preserves
 * existing project (meetwoyou-436a2), collections, and auth flow.
 */
import { firebaseConfig } from './config.js';

const SDK = 'https://www.gstatic.com/firebasejs/10.8.0';
let _ready;

export function fb() {
  if (_ready) return _ready;
  _ready = (async () => {
    const [{ initializeApp, getApps }, auth, db, storage] = await Promise.all([
      import(`${SDK}/firebase-app.js`),
      import(`${SDK}/firebase-auth.js`),
      import(`${SDK}/firebase-firestore.js`),
      import(`${SDK}/firebase-storage.js`),
    ]);
    const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
    const authInstance = auth.getAuth(app);
    const dbInstance = db.getFirestore(app);
    const storageInstance = storage.getStorage(app);

    // Expose globals for legacy compatibility (existing modules read these).
    window.firebaseApp = app;
    window.firebaseAuth = authInstance;
    window.firebaseDB = dbInstance;
    window.firebaseStorage = storageInstance;

    return { app, auth: authInstance, db: dbInstance, storage: storageInstance, sdk: { auth, db, storage } };
  })();
  return _ready;
}

export async function onAuth(cb) {
  const { auth, sdk } = await fb();
  return sdk.auth.onAuthStateChanged(auth, (user) => {
    window.currentUser = user || null;
    cb(user);
  });
}

export async function signIn(email, password) {
  const { auth, sdk } = await fb();
  return sdk.auth.signInWithEmailAndPassword(auth, email, password);
}

export async function signUp(email, password) {
  const { auth, sdk } = await fb();
  return sdk.auth.createUserWithEmailAndPassword(auth, email, password);
}

export async function signOutUser() {
  const { auth, sdk } = await fb();
  return sdk.auth.signOut(auth);
}

export async function sendReset(email) {
  const { auth, sdk } = await fb();
  return sdk.auth.sendPasswordResetEmail(auth, email);
}
