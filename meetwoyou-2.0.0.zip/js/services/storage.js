/** localStorage + IndexedDB wrapper with JSON safety and cache TTL. */
const NS = 'mw:';

export const store = {
  get(k, fallback = null) {
    try { const v = localStorage.getItem(NS + k); return v == null ? fallback : JSON.parse(v); }
    catch { return fallback; }
  },
  set(k, v) { try { localStorage.setItem(NS + k, JSON.stringify(v)); } catch {} },
  del(k) { try { localStorage.removeItem(NS + k); } catch {} },
  keys() { return Object.keys(localStorage).filter(k => k.startsWith(NS)).map(k => k.slice(NS.length)); },
  clear() { this.keys().forEach(k => this.del(k)); },
};

export const cache = {
  set(k, data, ttlSec = 300) { store.set('c:' + k, { data, exp: Date.now() + ttlSec * 1000 }); },
  get(k) {
    const c = store.get('c:' + k);
    if (!c) return null;
    if (Date.now() > c.exp) { store.del('c:' + k); return null; }
    return c.data;
  },
  wrap(k, ttl, loader) {
    const hit = this.get(k);
    if (hit) return Promise.resolve(hit);
    return Promise.resolve(loader()).then(d => { this.set(k, d, ttl); return d; });
  },
};

// IndexedDB minimal helper for media / offline queues
const DB_NAME = 'meetwoyou';
const DB_VERSION = 1;
let _db;
export function idb() {
  if (_db) return _db;
  _db = new Promise((res, rej) => {
    const r = indexedDB.open(DB_NAME, DB_VERSION);
    r.onupgradeneeded = () => {
      const db = r.result;
      if (!db.objectStoreNames.contains('kv')) db.createObjectStore('kv');
      if (!db.objectStoreNames.contains('outbox')) db.createObjectStore('outbox', { keyPath: 'id', autoIncrement: true });
    };
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
  return _db;
}
export async function idbSet(store_, key, val) {
  const db = await idb();
  return new Promise((res, rej) => {
    const tx = db.transaction(store_, 'readwrite');
    const req = key == null ? tx.objectStore(store_).add(val) : tx.objectStore(store_).put(val, key);
    req.onsuccess = () => res(req.result);
    req.onerror = () => rej(req.error);
  });
}
export async function idbGet(store_, key) {
  const db = await idb();
  return new Promise((res, rej) => {
    const req = db.transaction(store_).objectStore(store_).get(key);
    req.onsuccess = () => res(req.result);
    req.onerror = () => rej(req.error);
  });
}
