/** Auth service — wraps firebase auth with app-level session, roles, logs. */
import { onAuth, signIn, signUp, signOutUser, sendReset, fb } from './firebase.js';
import { COLLECTIONS } from './config.js';
import { store } from './storage.js';

const LOG_KEY = 'auth:log';
const SESSIONS_KEY = 'auth:sessions';
const ADMIN_EMAILS_KEY = 'auth:adminEmails';

// Bootstrap default admin list (configurable via admin panel).
if (!store.get(ADMIN_EMAILS_KEY)) store.set(ADMIN_EMAILS_KEY, ['admin@meetwoyou.com']);

const listeners = new Set();
export function onSession(cb) { listeners.add(cb); return () => listeners.delete(cb); }
function emit(state) { listeners.forEach(l => { try { l(state); } catch {} }); }

let current = null;
export function getSession() { return current; }
export function isAdmin(user = current) {
  if (!user) return false;
  const admins = store.get(ADMIN_EMAILS_KEY, []);
  return admins.includes(user.email);
}

export async function init() {
  await onAuth(async (user) => {
    current = user;
    if (user) {
      logEvent('login', user);
      trackSession(user);
      await ensureProfile(user);
    } else {
      logEvent('logout', null);
    }
    emit({ user, admin: isAdmin(user) });
  });
}

export async function ensureProfile(user) {
  try {
    const { db, sdk } = await fb();
    const ref = sdk.db.doc(db, COLLECTIONS.users, user.uid);
    const snap = await sdk.db.getDoc(ref);
    if (!snap.exists()) {
      await sdk.db.setDoc(ref, {
        uid: user.uid,
        email: user.email,
        displayName: user.displayName || user.email?.split('@')[0] || 'User',
        photoURL: user.photoURL || null,
        createdAt: sdk.db.serverTimestamp(),
        verified: null,
        premium: false,
      });
    }
  } catch (e) { console.warn('ensureProfile', e); }
}

export async function login(email, password) {
  try { const cred = await signIn(email, password); logEvent('login.ok', cred.user); return cred; }
  catch (e) { logEvent('login.fail', null, { email, code: e.code }); throw e; }
}
export async function register(email, password) {
  const cred = await signUp(email, password);
  logEvent('register', cred.user);
  return cred;
}
export async function logout() { await signOutUser(); }
export async function reset(email) { await sendReset(email); logEvent('reset', null, { email }); }

function logEvent(type, user, extra = {}) {
  const log = store.get(LOG_KEY, []);
  log.unshift({ ts: Date.now(), type, uid: user?.uid || null, email: user?.email || extra.email || null, ua: navigator.userAgent.slice(0, 120), ...extra });
  store.set(LOG_KEY, log.slice(0, 200));
}
export function getLogs() { return store.get(LOG_KEY, []); }

function trackSession(user) {
  const sessions = store.get(SESSIONS_KEY, []);
  sessions.unshift({ id: crypto.randomUUID(), uid: user.uid, device: navigator.userAgent.slice(0, 120), created: Date.now() });
  store.set(SESSIONS_KEY, sessions.slice(0, 20));
}
export function getSessions() { return store.get(SESSIONS_KEY, []); }
export function revokeSession(id) { store.set(SESSIONS_KEY, getSessions().filter(s => s.id !== id)); }

export function addAdmin(email) {
  const l = store.get(ADMIN_EMAILS_KEY, []); if (!l.includes(email)) l.push(email); store.set(ADMIN_EMAILS_KEY, l);
}
export function removeAdmin(email) {
  store.set(ADMIN_EMAILS_KEY, store.get(ADMIN_EMAILS_KEY, []).filter(e => e !== email));
}
export function listAdmins() { return store.get(ADMIN_EMAILS_KEY, []); }
