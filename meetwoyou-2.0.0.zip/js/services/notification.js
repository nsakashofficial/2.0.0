/** In-app toast + push notification service. No alert() ever. */
const container = () => {
  let el = document.getElementById('mw-toast');
  if (!el) { el = document.createElement('div'); el.id = 'mw-toast'; el.setAttribute('role','status'); el.setAttribute('aria-live','polite'); document.body.appendChild(el); }
  return el;
};

export function toast(message, { type = 'info', duration = 3200, action } = {}) {
  const c = container();
  const t = document.createElement('div');
  t.className = `mw-toast mw-toast--${type}`;
  t.innerHTML = `<span class="mw-toast__msg"></span>`;
  t.querySelector('.mw-toast__msg').textContent = message;
  if (action) {
    const b = document.createElement('button');
    b.className = 'mw-toast__action'; b.type = 'button'; b.textContent = action.label;
    b.addEventListener('click', () => { action.onClick?.(); t.remove(); });
    t.appendChild(b);
  }
  c.appendChild(t);
  requestAnimationFrame(() => t.classList.add('is-in'));
  setTimeout(() => { t.classList.remove('is-in'); t.addEventListener('transitionend', () => t.remove(), { once: true }); }, duration);
  return t;
}

export async function requestPush() {
  if (!('Notification' in window)) return 'unsupported';
  if (Notification.permission === 'granted') return 'granted';
  return await Notification.requestPermission();
}

export function pushLocal(title, opts = {}) {
  if (!('Notification' in window) || Notification.permission !== 'granted') return null;
  try { return new Notification(title, { icon: '/assets/icons/favicon-192x192.png', ...opts }); }
  catch { return null; }
}
