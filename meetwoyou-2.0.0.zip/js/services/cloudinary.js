/**
 * Cloudinary upload service — preserves existing cloud (dpgawb5sl) and the
 * unsigned "Meetwoyou" preset. Do NOT migrate media — legacy URLs stay valid.
 */
import { cloudinary } from './config.js';

export async function uploadMedia(file, { folder = 'uploads', onProgress } = {}) {
  if (!file) throw new Error('No file');
  const fd = new FormData();
  fd.append('file', file);
  fd.append('upload_preset', cloudinary.uploadPreset);
  if (folder) fd.append('folder', folder);

  return await new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', cloudinary.uploadUrl());
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable && onProgress) onProgress(e.loaded / e.total);
    };
    xhr.onload = () => {
      try {
        const json = JSON.parse(xhr.responseText);
        if (xhr.status >= 200 && xhr.status < 300) resolve(json);
        else reject(new Error(json.error?.message || `Upload failed (${xhr.status})`));
      } catch (err) { reject(err); }
    };
    xhr.onerror = () => reject(new Error('Network error during upload'));
    xhr.send(fd);
  });
}

// Legacy compatibility for older inline scripts that expect window.uploadCloud
if (typeof window !== 'undefined') window.uploadCloud = (f, opts) => uploadMedia(f, opts || {});

/** Build a transformed Cloudinary URL from an existing secure_url. */
export function transform(url, params = 'f_auto,q_auto,w_800') {
  if (!url || !url.includes('/upload/')) return url;
  return url.replace('/upload/', `/upload/${params}/`);
}
