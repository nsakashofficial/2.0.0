/**
 * Runtime config — reads window.__MW_ENV__ if present (injected by hosting
 * or by /env.js), falls back to the existing production values so the app
 * keeps working out of the box against the current Firebase + Cloudinary
 * setup. Do NOT hardcode new credentials here; extend .env / env.js.
 */
const ENV = (typeof window !== 'undefined' && window.__MW_ENV__) || {};

export const firebaseConfig = {
  apiKey: ENV.FIREBASE_API_KEY || 'AIzaSyBn3x2qSo8k6a9wrxNfLmVliWMmsUk8wfY',
  authDomain: ENV.FIREBASE_AUTH_DOMAIN || 'meetwoyou-436a2.firebaseapp.com',
  projectId: ENV.FIREBASE_PROJECT_ID || 'meetwoyou-436a2',
  storageBucket: ENV.FIREBASE_STORAGE_BUCKET || 'meetwoyou-436a2.firebasestorage.app',
  messagingSenderId: ENV.FIREBASE_MESSAGING_SENDER_ID || '612788132077',
  appId: ENV.FIREBASE_APP_ID || '1:612788132077:web:0a8b92edf26778efd4d4e4',
};

export const cloudinary = {
  cloudName: ENV.CLOUDINARY_CLOUD_NAME || 'dpgawb5sl',
  uploadPreset: ENV.CLOUDINARY_UPLOAD_PRESET || 'Meetwoyou',
  uploadUrl() {
    return `https://api.cloudinary.com/v1_1/${this.cloudName}/auto/upload`;
  },
};

/** Firestore collection names — must stay identical to legacy schema. */
export const COLLECTIONS = Object.freeze({
  users: 'users',
  chats: 'chats',
  activity: 'activity',
  calls: 'calls',
  offerCands: 'offerCands',
  ansCands: 'ansCands',
});

export const APP = {
  name: 'Meetwoyou',
  version: '2.0.0',
  supportEmail: 'support@meetwoyou.com',
};
