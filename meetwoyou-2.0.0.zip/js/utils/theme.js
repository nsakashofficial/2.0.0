/** Theme (light/dark), respects user preference and persists. */
import { store } from '../services/storage.js';
const KEY = 'theme';
export function currentTheme() { return store.get(KEY) || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'); }
export function applyTheme(t = currentTheme()) {
  document.documentElement.dataset.theme = t;
  document.documentElement.style.colorScheme = t;
  store.set(KEY, t);
}
export function toggleTheme() { applyTheme(currentTheme() === 'dark' ? 'light' : 'dark'); }
