/** i18n scaffold — English by default; add strings as needed. */
const dict = {
  en: {
    home: 'Home', messages: 'Messages', search: 'Search', profile: 'Profile', settings: 'Settings',
    create: 'Create', signIn: 'Sign in', signUp: 'Sign up', signOut: 'Sign out',
  },
};
let lang = 'en';
export function t(key) { return dict[lang]?.[key] ?? dict.en[key] ?? key; }
export function setLang(l) { if (dict[l]) lang = l; document.documentElement.lang = lang; }
