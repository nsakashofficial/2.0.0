/** Hash-based router with lazy modules. Works on GitHub Pages (no server rewrites). */
const routes = new Map();
let notFound = null;

export function route(path, loader) { routes.set(path, loader); }
export function setNotFound(loader) { notFound = loader; }

export function navigate(path) { location.hash = path.startsWith('#') ? path : '#' + path; }

function current() {
  const raw = location.hash.replace(/^#/, '') || '/';
  const [path, query = ''] = raw.split('?');
  const params = Object.fromEntries(new URLSearchParams(query));
  return { path, params, raw };
}

async function render(root) {
  const { path, params } = current();
  const loader = routes.get(path) || matchDynamic(path) || notFound;
  if (!loader) { root.innerHTML = '<div class="mw-empty">Page not found.</div>'; return; }
  root.innerHTML = '<div class="mw-skeleton"></div>';
  try {
    const mod = await loader();
    const view = await (mod.default || mod.render)?.({ params, path });
    root.replaceChildren(view instanceof Node ? view : document.createTextNode(''));
    document.dispatchEvent(new CustomEvent('mw:navigated', { detail: { path } }));
    window.scrollTo({ top: 0 });
  } catch (e) {
    console.error(e);
    root.innerHTML = `<div class="mw-empty mw-empty--error"><h3>Something went wrong</h3><p>${e.message||e}</p><button class="mw-btn" onclick="location.reload()">Reload</button></div>`;
  }
}

function matchDynamic(path) {
  for (const [pattern, loader] of routes) {
    if (!pattern.includes(':')) continue;
    const rx = new RegExp('^' + pattern.replace(/:[a-zA-Z]+/g, '([^/]+)') + '$');
    if (rx.test(path)) return loader;
  }
  return null;
}

export function start(rootSelector = '#app') {
  const root = document.querySelector(rootSelector);
  addEventListener('hashchange', () => render(root));
  render(root);
}

export function currentRoute() { return current(); }
