import { h } from '../utils/dom.js';
import { postCard } from '../components/cards.js';
import { fb } from '../services/firebase.js';
import { COLLECTIONS } from '../services/config.js';
import { cache } from '../services/storage.js';

async function loadFeed() {
  return cache.wrap('feed:home', 60, async () => {
    try {
      const { db, sdk } = await fb();
      const q = sdk.db.query(sdk.db.collection(db, COLLECTIONS.activity), sdk.db.orderBy('createdAt', 'desc'), sdk.db.limit(25));
      const snap = await sdk.db.getDocs(q);
      return snap.docs.map(d => ({ id: d.id, ...d.data(), createdAt: d.data().createdAt?.toMillis?.() || Date.now() }));
    } catch (e) { console.warn('feed offline', e); return []; }
  });
}

export default async function view() {
  const root = h('section', { class: 'mw-view mw-view--home' },
    h('div', { class: 'mw-container' },
      h('div', { class: 'mw-feed' }, h('div', { class: 'mw-skeleton mw-skeleton--card' })),
    ),
  );
  const feedEl = root.querySelector('.mw-feed');
  const posts = await loadFeed();
  feedEl.innerHTML = '';
  if (!posts.length) {
    feedEl.appendChild(h('div', { class: 'mw-empty' },
      h('h3', {}, 'Your feed is empty'),
      h('p', {}, 'Follow people or create your first post to get started.'),
    ));
  } else {
    posts.forEach(p => feedEl.appendChild(postCard(p)));
  }
  return root;
}
