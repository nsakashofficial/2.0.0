import { h } from '../utils/dom.js';
import { getSession, logout } from '../services/auth.js';
import { verifiedBadge } from '../components/badge.js';
import { button } from '../components/buttons.js';
import { navigate } from '../utils/router.js';
import { toast } from '../services/notification.js';

export default async function view() {
  const user = getSession();
  if (!user) return h('div', { class: 'mw-container' },
    h('div', { class: 'mw-empty' }, h('h3', {}, 'Sign in to view your profile'),
      button({ label: 'Sign in', onClick: () => navigate('/auth') })));

  return h('section', { class: 'mw-view mw-view--profile' },
    h('div', { class: 'mw-container' },
      h('div', { class: 'mw-profile__head' },
        h('div', { class: 'mw-profile__avatar' },
          user.photoURL ? h('img', { src: user.photoURL, alt: '' }) : h('span', {}, (user.email || '?')[0].toUpperCase())),
        h('div', { class: 'mw-profile__meta' },
          h('h1', { class: 'mw-profile__name' }, user.displayName || user.email.split('@')[0], verifiedBadge('blue', { size: 20 })),
          h('p', { class: 'mw-profile__email' }, user.email),
          h('div', { class: 'mw-profile__stats' },
            stat('Posts', 0), stat('Followers', 0), stat('Following', 0),
          ),
        ),
      ),
      h('div', { class: 'mw-profile__actions' },
        button({ label: 'Edit profile', variant: 'ghost', onClick: () => navigate('/settings') }),
        button({ label: 'Creator studio', variant: 'primary', onClick: () => navigate('/creator') }),
        button({ label: 'Sign out', variant: 'danger', onClick: async () => { await logout(); toast('Signed out'); navigate('/auth'); } }),
      ),
      h('div', { class: 'mw-empty' }, h('p', {}, 'No posts yet.')),
    ),
  );
}
function stat(l, v) { return h('div', { class: 'mw-profile__stat' }, h('strong', {}, String(v)), h('span', {}, l)); }
