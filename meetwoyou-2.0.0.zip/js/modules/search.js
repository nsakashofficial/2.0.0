import { h, debounce } from '../utils/dom.js';
import { fb } from '../services/firebase.js';
import { COLLECTIONS } from '../services/config.js';

export default async function view() {
  const results = h('div', { class: 'mw-search__results' });
  const tabs = ['Users', 'Posts', 'Messages'];
  let active = 'Users';

  async function run(q) {
    results.innerHTML = q ? '<div class="mw-skeleton"></div>' : '';
    if (!q) return;
    try {
      const { db, sdk } = await fb();
      let items = [];
      if (active === 'Users') {
        const snap = await sdk.db.getDocs(sdk.db.query(sdk.db.collection(db, COLLECTIONS.users), sdk.db.limit(20)));
        items = snap.docs.map(d => d.data()).filter(u => (u.displayName || u.email || '').toLowerCase().includes(q.toLowerCase()));
      } else if (active === 'Posts') {
        const snap = await sdk.db.getDocs(sdk.db.query(sdk.db.collection(db, COLLECTIONS.activity), sdk.db.limit(30)));
        items = snap.docs.map(d => d.data()).filter(p => (p.text || '').toLowerCase().includes(q.toLowerCase()));
      }
      results.innerHTML = '';
      if (!items.length) { results.appendChild(h('div', { class: 'mw-empty' }, 'No results')); return; }
      items.forEach(i => results.appendChild(h('div', { class: 'mw-card mw-search__row' },
        h('strong', {}, i.displayName || i.text?.slice(0, 60) || i.email || 'Result'),
        i.email ? h('span', { class: 'mw-muted' }, i.email) : null,
      )));
    } catch (e) { results.innerHTML = `<div class="mw-empty">${e.message}</div>`; }
  }

  const input = h('input', {
    class: 'mw-input', type: 'search', placeholder: 'Search users, posts, messages…', 'aria-label': 'Search',
    oninput: debounce(e => run(e.target.value.trim()), 300),
  });
  const tabBar = h('div', { class: 'mw-tabs' }, ...tabs.map(t => h('button', {
    class: 'mw-tabs__item' + (t === active ? ' is-active' : ''),
    onclick: (e) => { active = t; tabBar.querySelectorAll('button').forEach(b => b.classList.remove('is-active')); e.currentTarget.classList.add('is-active'); run(input.value.trim()); },
  }, t)));

  return h('section', { class: 'mw-view' }, h('div', { class: 'mw-container' }, input, tabBar, results));
}
