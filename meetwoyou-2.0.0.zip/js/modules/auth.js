import { h } from '../utils/dom.js';
import { getSession, login, register, reset } from '../services/auth.js';
import { navigate } from '../utils/router.js';
import { toast } from '../services/notification.js';

export default async function view() {
  if (getSession()) { navigate('/'); return h('div'); }
  let mode = 'in';
  const root = h('section', { class: 'mw-view mw-auth' }, h('div', { class: 'mw-auth__card' }));
  const card = root.querySelector('.mw-auth__card');
  render();
  function render() {
    card.innerHTML = '';
    card.append(
      h('h1', { class: 'mw-auth__brand' }, 'Meetwoyou'),
      h('p', { class: 'mw-auth__sub' }, mode === 'in' ? 'Welcome back' : 'Create your account'),
      h('form', { class: 'mw-auth__form', onsubmit: submit },
        h('input', { class: 'mw-input', type: 'email', name: 'email', placeholder: 'Email', required: true, autocomplete: 'email' }),
        h('input', { class: 'mw-input', type: 'password', name: 'password', placeholder: 'Password', minlength: 6, required: true, autocomplete: mode === 'in' ? 'current-password' : 'new-password' }),
        h('button', { class: 'mw-btn mw-btn--primary', type: 'submit' }, mode === 'in' ? 'Sign in' : 'Create account'),
      ),
      h('div', { class: 'mw-auth__row' },
        h('button', { class: 'mw-btn mw-btn--link', onclick: () => { mode = mode === 'in' ? 'up' : 'in'; render(); } }, mode === 'in' ? 'Create account' : 'Sign in instead'),
        mode === 'in' ? h('button', { class: 'mw-btn mw-btn--link', onclick: forgot }, 'Forgot password?') : null,
      ),
    );
  }
  async function submit(e) {
    e.preventDefault();
    const email = e.target.email.value.trim(), password = e.target.password.value;
    try {
      if (mode === 'in') await login(email, password); else await register(email, password);
      toast('Welcome to Meetwoyou'); navigate('/');
    } catch (err) { toast(err.message, { type: 'error' }); }
  }
  async function forgot() {
    const email = card.querySelector('input[type=email]').value.trim();
    if (!email) return toast('Enter your email first', { type: 'error' });
    try { await reset(email); toast('Password reset sent'); } catch (e) { toast(e.message, { type: 'error' }); }
  }
  return root;
}
