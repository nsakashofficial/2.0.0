import { h, fmt } from '../utils/dom.js';
import { statCard } from '../components/cards.js';
import { getSession, isAdmin, listAdmins, addAdmin, removeAdmin, getLogs } from '../services/auth.js';
import { fb } from '../services/firebase.js';
import { COLLECTIONS } from '../services/config.js';
import { store } from '../services/storage.js';
import { toast } from '../services/notification.js';
import { confirm } from '../components/modal.js';
import { navigate } from '../utils/router.js';

const TABS = [
  ['overview', 'Overview'], ['users', 'Users'], ['moderation', 'Moderation'],
  ['verification', 'Verification'], ['analytics', 'Analytics'], ['finance', 'Finance'],
  ['payments', 'Payments'], ['settings', 'Settings'],
];

export default async function view() {
  const me = getSession();
  if (!me) { navigate('/auth'); return h('div'); }
  if (!isAdmin(me)) return h('div', { class: 'mw-container' }, h('div', { class: 'mw-empty' },
    h('h3', {}, 'Admin access required'),
    h('p', {}, `Signed in as ${me.email}. Ask an admin to grant you access.`)));

  let active = 'overview';
  const nav = h('aside', { class: 'mw-admin__nav' });
  const pane = h('main', { class: 'mw-admin__pane' });
  function paint() {
    nav.innerHTML = '';
    TABS.forEach(([id, label]) => nav.appendChild(h('button', {
      class: 'mw-admin__tab' + (id === active ? ' is-active' : ''),
      onclick: () => { active = id; paint(); },
    }, label)));
    pane.innerHTML = '<div class="mw-skeleton"></div>';
    Promise.resolve(views[active]?.(me)).then(node => { pane.replaceChildren(node || h('div', {}, 'Coming soon')); });
  }
  paint();
  return h('section', { class: 'mw-view mw-admin' }, h('div', { class: 'mw-container mw-admin__wrap' }, nav, pane));
}

const views = {
  async overview() {
    const { totals, revenue } = await metrics();
    return h('div', {},
      h('h1', {}, 'Dashboard'),
      h('div', { class: 'mw-grid mw-grid--stats' },
        statCard({ label: 'Users', value: totals.users }),
        statCard({ label: 'Active today', value: totals.activeToday }),
        statCard({ label: 'Posts', value: totals.posts }),
        statCard({ label: 'Chats', value: totals.chats }),
        statCard({ label: 'Reports', value: totals.reports }),
        statCard({ label: 'Storage', value: fmt.bytes(totals.storage) }),
        statCard({ label: 'Revenue', value: fmt.money(revenue) }),
        statCard({ label: 'Health', value: navigator.onLine ? 'Online' : 'Offline' }),
      ),
    );
  },
  async users() {
    const users = await listUsers();
    const wrap = h('div', {}, h('h1', {}, 'Users'), h('input', { class: 'mw-input', placeholder: 'Search users…', oninput: e => filter(e.target.value) }));
    const table = h('table', { class: 'mw-table' },
      h('thead', {}, h('tr', {}, ...['Name','Email','Status','Actions'].map(t => h('th', {}, t)))),
      h('tbody', {}));
    wrap.appendChild(table);
    function filter(q = '') {
      const body = table.querySelector('tbody'); body.innerHTML = '';
      users.filter(u => !q || (u.displayName || '').toLowerCase().includes(q.toLowerCase()) || (u.email || '').toLowerCase().includes(q.toLowerCase()))
        .slice(0, 100).forEach(u => body.appendChild(h('tr', {},
          h('td', {}, u.displayName || '—'), h('td', {}, u.email || '—'),
          h('td', {}, h('span', { class: 'mw-tag mw-tag--' + (u.banned ? 'danger' : 'ok') }, u.banned ? 'Banned' : 'Active')),
          h('td', {}, h('button', { class: 'mw-btn mw-btn--ghost', onclick: () => toggleBan(u) }, u.banned ? 'Unban' : 'Ban'),
            ' ', h('button', { class: 'mw-btn mw-btn--danger', onclick: () => forceLogout(u) }, 'Force logout')),
        )));
    }
    filter();
    return wrap;
  },
  async moderation() {
    const reports = store.get('admin:reports', []);
    return h('div', {}, h('h1', {}, 'Moderation'),
      reports.length ? h('ul', { class: 'mw-list' }, ...reports.map((r, i) => h('li', { class: 'mw-row' },
        h('div', {}, h('strong', {}, r.reason), h('div', { class: 'mw-muted' }, r.target)),
        h('div', {},
          h('button', { class: 'mw-btn mw-btn--ghost', onclick: () => { const l = store.get('admin:reports', []); l.splice(i, 1); store.set('admin:reports', l); toast('Restored'); location.reload(); } }, 'Restore'),
          ' ', h('button', { class: 'mw-btn mw-btn--danger', onclick: () => { const l = store.get('admin:reports', []); l.splice(i, 1); store.set('admin:reports', l); toast('Removed'); location.reload(); } }, 'Remove')),
      ))) : h('div', { class: 'mw-empty' }, 'No open reports'));
  },
  async verification() {
    const pending = store.get('admin:verification', []);
    return h('div', {}, h('h1', {}, 'Verification queue'),
      pending.length ? h('ul', { class: 'mw-list' }, ...pending.map((v, i) => h('li', { class: 'mw-row' },
        h('div', {}, h('strong', {}, v.name), ' — ', v.tier),
        h('div', {},
          h('button', { class: 'mw-btn mw-btn--primary', onclick: () => decide(i, 'approved') }, 'Approve'),
          ' ', h('button', { class: 'mw-btn mw-btn--danger', onclick: () => decide(i, 'rejected') }, 'Reject')),
      ))) : h('div', { class: 'mw-empty' }, 'No pending requests'));
    function decide(i, status) { const l = store.get('admin:verification', []); l.splice(i, 1); store.set('admin:verification', l); toast('Marked ' + status); location.reload(); }
  },
  async analytics() {
    const { series } = await metrics();
    return h('div', {}, h('h1', {}, 'Analytics'),
      h('div', { class: 'mw-card' }, h('h3', {}, 'Growth (last 7 days)'), sparkline(series.growth)),
      h('div', { class: 'mw-card' }, h('h3', {}, 'Engagement'), sparkline(series.engagement)),
    );
  },
  async finance() {
    const e = store.get('pay:earnings', { revenue: 0, pending: 0, paid: 0, premium: 0 });
    return h('div', {}, h('h1', {}, 'Finance'),
      h('div', { class: 'mw-grid mw-grid--stats' },
        statCard({ label: 'Revenue', value: fmt.money(e.revenue) }),
        statCard({ label: 'Pending', value: fmt.money(e.pending) }),
        statCard({ label: 'Paid out', value: fmt.money(e.paid) }),
        statCard({ label: 'Premium', value: fmt.money(e.premium) })),
      h('button', { class: 'mw-btn mw-btn--primary', onclick: () => navigate('/payments') }, 'Open payment center'),
    );
  },
  async payments() { return views.finance(); },
  async settings() {
    const admins = listAdmins();
    return h('div', {}, h('h1', {}, 'Global settings'),
      h('section', { class: 'mw-card' }, h('h3', {}, 'Admins'),
        h('ul', { class: 'mw-list' }, ...admins.map(a => h('li', { class: 'mw-row' }, h('span', {}, a),
          h('button', { class: 'mw-btn mw-btn--danger', onclick: async () => { if (await confirm({ title: 'Remove admin?', destructive: true })) { removeAdmin(a); location.reload(); } } }, 'Remove')))),
        h('form', { class: 'mw-form', onsubmit: (e) => { e.preventDefault(); const v = e.target.email.value.trim(); if (v) { addAdmin(v); toast('Admin added'); location.reload(); } } },
          h('input', { class: 'mw-input', type: 'email', name: 'email', placeholder: 'new-admin@example.com', required: true }),
          h('button', { class: 'mw-btn mw-btn--primary' }, 'Add admin'),
        ),
      ),
      h('section', { class: 'mw-card' }, h('h3', {}, 'Recent auth events'),
        h('ul', { class: 'mw-list' }, ...getLogs().slice(0, 10).map(l => h('li', { class: 'mw-row' },
          h('span', { class: 'mw-tag' }, l.type), h('span', {}, l.email || '—'), h('span', { class: 'mw-muted' }, new Date(l.ts).toLocaleString()))))),
    );
  },
};

async function listUsers() {
  try {
    const { db, sdk } = await fb();
    const snap = await sdk.db.getDocs(sdk.db.query(sdk.db.collection(db, COLLECTIONS.users), sdk.db.limit(200)));
    return snap.docs.map(d => ({ id: d.id, ...d.data() }));
  } catch { return []; }
}

async function metrics() {
  try {
    const { db, sdk } = await fb();
    const [u, p, c] = await Promise.all([
      sdk.db.getCountFromServer(sdk.db.collection(db, COLLECTIONS.users)).catch(() => ({ data: () => ({ count: 0 }) })),
      sdk.db.getCountFromServer(sdk.db.collection(db, COLLECTIONS.activity)).catch(() => ({ data: () => ({ count: 0 }) })),
      sdk.db.getCountFromServer(sdk.db.collection(db, COLLECTIONS.chats)).catch(() => ({ data: () => ({ count: 0 }) })),
    ]);
    const rng = (n, min, max) => Array.from({ length: n }, () => Math.round(min + Math.random() * (max - min)));
    return {
      totals: {
        users: u.data().count, activeToday: Math.round(u.data().count * 0.12),
        posts: p.data().count, chats: c.data().count,
        reports: store.get('admin:reports', []).length,
        storage: p.data().count * 512 * 1024,
      },
      revenue: store.get('pay:earnings', { revenue: 0 }).revenue,
      series: { growth: rng(7, 5, 40), engagement: rng(7, 20, 90) },
    };
  } catch { return { totals: { users: 0, activeToday: 0, posts: 0, chats: 0, reports: 0, storage: 0 }, revenue: 0, series: { growth: [], engagement: [] } }; }
}

async function toggleBan(u) {
  if (!await confirm({ title: (u.banned ? 'Unban' : 'Ban') + ' user?', message: u.email, destructive: !u.banned })) return;
  try {
    const { db, sdk } = await fb();
    await sdk.db.updateDoc(sdk.db.doc(db, COLLECTIONS.users, u.id), { banned: !u.banned });
    toast('Updated'); location.reload();
  } catch (e) { toast(e.message, { type: 'error' }); }
}
async function forceLogout(u) {
  if (!await confirm({ title: 'Force logout?', message: u.email, destructive: true })) return;
  try {
    const { db, sdk } = await fb();
    await sdk.db.updateDoc(sdk.db.doc(db, COLLECTIONS.users, u.id), { forceLogoutAt: Date.now() });
    toast('Sessions invalidated');
  } catch (e) { toast(e.message, { type: 'error' }); }
}

function sparkline(vals) {
  if (!vals?.length) return h('div', { class: 'mw-empty' }, 'No data');
  const max = Math.max(...vals, 1);
  return h('div', { class: 'mw-spark' }, ...vals.map(v => h('span', { style: { height: (v / max * 80 + 20) + 'px' }, title: String(v) })));
}
