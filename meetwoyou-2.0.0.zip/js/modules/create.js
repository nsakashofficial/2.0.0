import { h } from '../utils/dom.js';
import { getSession } from '../services/auth.js';
import { uploadMedia } from '../services/cloudinary.js';
import { fb } from '../services/firebase.js';
import { COLLECTIONS } from '../services/config.js';
import { toast } from '../services/notification.js';
import { navigate } from '../utils/router.js';
import { cache } from '../services/storage.js';

export default async function view() {
  const me = getSession();
  if (!me) { navigate('/auth'); return h('div'); }

  const preview = h('div', { class: 'mw-create__preview' });
  const progress = h('div', { class: 'mw-progress', hidden: true }, h('div', { class: 'mw-progress__bar' }));
  const bar = progress.querySelector('.mw-progress__bar');
  let file = null, uploadedUrl = null;

  const form = h('form', { class: 'mw-create', onsubmit: submit },
    h('textarea', { class: 'mw-input mw-input--area', name: 'text', placeholder: "What's on your mind?", rows: 5 }),
    h('label', { class: 'mw-btn mw-btn--ghost' }, 'Add photo/video',
      h('input', { type: 'file', accept: 'image/*,video/*', hidden: true, onchange: pick })),
    progress,
    preview,
    h('div', { class: 'mw-create__actions' },
      h('button', { class: 'mw-btn mw-btn--primary', type: 'submit' }, 'Publish'),
    ),
  );

  async function pick(e) {
    file = e.target.files[0]; if (!file) return;
    preview.innerHTML = '';
    const url = URL.createObjectURL(file);
    preview.appendChild(file.type.startsWith('video') ? h('video', { src: url, controls: true }) : h('img', { src: url, alt: '' }));
    progress.hidden = false; bar.style.width = '0%';
    try {
      const res = await uploadMedia(file, { folder: `users/${me.uid}`, onProgress: p => { bar.style.width = (p * 100).toFixed(0) + '%'; } });
      uploadedUrl = res.secure_url;
      toast('Media uploaded');
    } catch (err) { toast(err.message, { type: 'error' }); progress.hidden = true; }
  }

  async function submit(e) {
    e.preventDefault();
    const text = e.target.text.value.trim();
    if (!text && !uploadedUrl) return toast('Add text or media first', { type: 'error' });
    try {
      const { db, sdk } = await fb();
      await sdk.db.addDoc(sdk.db.collection(db, COLLECTIONS.activity), {
        text, image: uploadedUrl,
        author: { uid: me.uid, name: me.displayName || me.email, photoURL: me.photoURL || null },
        createdAt: sdk.db.serverTimestamp(),
        likes: 0, comments: 0,
      });
      cache.set('feed:home', null, 0);
      toast('Published');
      navigate('/');
    } catch (err) { toast(err.message, { type: 'error' }); }
  }

  return h('section', { class: 'mw-view' }, h('div', { class: 'mw-container' }, h('h2', {}, 'Create'), form));
}
