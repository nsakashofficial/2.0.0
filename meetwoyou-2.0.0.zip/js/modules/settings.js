import { h } from '../utils/dom.js';
import { getSession, getSessions, revokeSession, getLogs } from '../services/auth.js';
import { store } from '../services/storage.js';
import { toast, requestPush } from '../services/notification.js';
import { currentTheme, applyTheme } from '../utils/theme.js';
import { navigate } from '../utils/router.js';

const SECTIONS = [
  ['account', 'Account'], ['privacy', 'Privacy'], ['security', 'Security'],
  ['notifications', 'Notifications'], ['appearance', 'Appearance'], ['messenger', 'Messenger'],
  ['monetization', 'Monetization'], ['storage', 'Storage'], ['language', 'Language'],
];

export default async function view() {
  const me = getSession();
  if (!me) { navigate('/auth'); return h('div'); }
  let active = 'account';
  const nav = h('aside', { class: 'mw-settings__nav' });
  const pane = h('main', { class: 'mw-settings__pane' });
  function renderNav() {
    nav.innerHTML = '';
    SECTIONS.forEach(([id, label]) => nav.appendChild(h('button', {
      class: 'mw-settings__navitem' + (id === active ? ' is-active' : ''),
      onclick: () => { active = id; renderNav(); renderPane(); },
    }, label)));
  }
  function renderPane() {
    pane.innerHTML = '';
    pane.appendChild(sections[active](me));
  }
  renderNav(); renderPane();
  return h('section', { class: 'mw-view mw-settings' }, h('div', { class: 'mw-container mw-settings__wrap' }, nav, pane));
}

const sections = {
  account: (me) => panel('Account',
    row('Email', me.email),
    row('Display name', me.displayName || me.email.split('@')[0]),
    row('User ID', me.uid),
  ),
  privacy: () => panel('Privacy',
    toggle('Private account', 'privacy.private'),
    toggle('Hide activity status', 'privacy.hideActive', true),
    toggle('Allow message requests', 'privacy.msgRequests', true),
  ),
  security: () => panel('Security',
    toggle('Two-factor authentication (SMS)', 'sec.2fa'),
    h('h4', {}, 'Active sessions'),
    ...getSessions().map(s => h('div', { class: 'mw-row' },
      h('div', {}, h('strong', {}, s.device), h('div', { class: 'mw-muted' }, new Date(s.created).toLocaleString())),
      h('button', { class: 'mw-btn mw-btn--danger', onclick: () => { revokeSession(s.id); toast('Session revoked'); location.reload(); } }, 'Revoke'),
    )),
    h('h4', {}, 'Login logs'),
    h('div', { class: 'mw-logs' }, ...getLogs().slice(0, 20).map(l => h('div', { class: 'mw-log' },
      h('span', { class: 'mw-tag' }, l.type), h('span', {}, l.email || '—'), h('span', { class: 'mw-muted' }, new Date(l.ts).toLocaleString())))),
  ),
  notifications: () => panel('Notifications',
    h('button', { class: 'mw-btn mw-btn--ghost', onclick: async () => toast('Push: ' + await requestPush()) }, 'Enable push notifications'),
    toggle('In-app notifications', 'notif.inApp', true),
    toggle('Email digest', 'notif.email'),
  ),
  appearance: () => panel('Appearance',
    h('div', { class: 'mw-row' }, h('span', {}, 'Theme'),
      h('div', {},
        h('button', { class: 'mw-btn' + (currentTheme() === 'light' ? ' mw-btn--primary' : ' mw-btn--ghost'), onclick: () => { applyTheme('light'); location.reload(); } }, 'Light'),
        ' ',
        h('button', { class: 'mw-btn' + (currentTheme() === 'dark' ? ' mw-btn--primary' : ' mw-btn--ghost'), onclick: () => { applyTheme('dark'); location.reload(); } }, 'Dark'),
      )),
  ),
  messenger: () => panel('Messenger',
    toggle('Read receipts', 'msg.reads', true),
    toggle('Typing indicators', 'msg.typing', true),
    toggle('Message previews on lock screen', 'msg.previews', true),
  ),
  monetization: () => panel('Monetization',
    h('p', {}, 'Set up your payout accounts and view earnings from the payment center.'),
    h('button', { class: 'mw-btn mw-btn--primary', onclick: () => navigate('/payments') }, 'Open payment center'),
  ),
  storage: () => panel('Storage',
    row('Local cache', `${Object.keys(localStorage).length} keys`),
    h('button', { class: 'mw-btn mw-btn--danger', onclick: () => { store.clear(); toast('Cache cleared'); } }, 'Clear cache'),
  ),
  language: () => panel('Language',
    h('select', { class: 'mw-input', onchange: (e) => { store.set('lang', e.target.value); toast('Language updated'); } },
      ['en','es','fr','ar','hi','bn'].map(l => h('option', { value: l, selected: (store.get('lang') || 'en') === l }, l.toUpperCase()))),
  ),
};

function panel(title, ...children) { return h('div', {}, h('h2', {}, title), ...children); }
function row(k, v) { return h('div', { class: 'mw-row' }, h('span', {}, k), h('strong', {}, v)); }
function toggle(label, key, def = false) {
  const on = store.get(key, def);
  return h('label', { class: 'mw-row mw-toggle' }, h('span', {}, label),
    h('input', { type: 'checkbox', checked: on, onchange: e => { store.set(key, e.target.checked); toast('Saved'); } }));
}
