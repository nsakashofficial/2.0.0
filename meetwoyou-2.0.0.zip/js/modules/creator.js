import { h } from '../utils/dom.js';
import { getSession } from '../services/auth.js';
import { statCard } from '../components/cards.js';
import { navigate } from '../utils/router.js';

export default async function view() {
  const me = getSession();
  if (!me) { navigate('/auth'); return h('div'); }
  return h('section', { class: 'mw-view' }, h('div', { class: 'mw-container' },
    h('h1', {}, 'Creator studio'),
    h('div', { class: 'mw-grid mw-grid--stats' },
      statCard({ label: 'Reach (7d)', value: 0, hint: 'Impressions across posts' }),
      statCard({ label: 'Followers', value: 0, delta: 0 }),
      statCard({ label: 'Engagement', value: '0%', hint: 'Interactions / reach' }),
      statCard({ label: 'Earnings', value: '$0.00' }),
    ),
    h('div', { class: 'mw-card' }, h('h3', {}, 'Insights'),
      h('p', { class: 'mw-muted' }, 'Detailed analytics appear once your posts start receiving views.')),
    h('button', { class: 'mw-btn mw-btn--primary', onclick: () => navigate('/payments') }, 'Manage payouts'),
  ));
}
