import { h, escapeHtml, fmt } from '../utils/dom.js';
import { getSession } from '../services/auth.js';
import { fb } from '../services/firebase.js';
import { COLLECTIONS } from '../services/config.js';
import { chatCard } from '../components/cards.js';
import { toast } from '../services/notification.js';

export default async function view({ params }) {
  const me = getSession();
  if (!me) return h('div', { class: 'mw-container' }, h('div', { class: 'mw-empty' }, 'Sign in to use messenger'));

  const list = h('aside', { class: 'mw-msgr__list' }, h('div', { class: 'mw-skeleton' }));
  const pane = h('main', { class: 'mw-msgr__pane' }, h('div', { class: 'mw-empty' }, 'Select a conversation'));

  const layout = h('section', { class: 'mw-view mw-msgr' }, list, pane);

  try {
    const { db, sdk } = await fb();
    const snap = await sdk.db.getDocs(sdk.db.query(sdk.db.collection(db, COLLECTIONS.chats), sdk.db.limit(50)));
    const chats = snap.docs.map(d => ({ id: d.id, ...d.data() }))
      .filter(c => Array.isArray(c.members) ? c.members.includes(me.uid) : true);
    list.innerHTML = '';
    if (!chats.length) list.appendChild(h('div', { class: 'mw-empty' }, 'No conversations yet'));
    chats.forEach(c => list.appendChild(chatCard({
      name: c.title || c.name || (c.members || []).find(u => u !== me.uid) || 'Chat',
      lastMsg: c.lastMessage || '',
      lastAt: c.updatedAt?.toMillis?.() || c.updatedAt || 0,
      unread: c.unread?.[me.uid] || 0,
    }, () => openChat(c))));
    if (params.chat) {
      const target = chats.find(c => c.id === params.chat);
      if (target) openChat(target);
    }
  } catch (e) { list.innerHTML = `<div class="mw-empty">${e.message}</div>`; }

  async function openChat(chat) {
    pane.innerHTML = '';
    const msgs = h('div', { class: 'mw-msgr__messages' });
    const composer = h('form', { class: 'mw-msgr__composer', onsubmit: send },
      h('input', { class: 'mw-input', name: 'text', placeholder: 'Message…', autocomplete: 'off' }),
      h('button', { class: 'mw-btn mw-btn--primary', type: 'submit' }, 'Send'),
    );
    pane.append(
      h('header', { class: 'mw-msgr__header' }, h('strong', {}, chat.title || chat.name || 'Chat')),
      msgs, composer,
    );

    const { db, sdk } = await fb();
    const q = sdk.db.query(sdk.db.collection(db, COLLECTIONS.chats, chat.id, 'messages'), sdk.db.orderBy('createdAt', 'asc'), sdk.db.limit(200));
    sdk.db.onSnapshot(q, (s) => {
      msgs.innerHTML = '';
      s.docs.forEach(d => {
        const m = d.data();
        const mine = m.from === me.uid;
        msgs.appendChild(h('div', { class: 'mw-msg ' + (mine ? 'is-mine' : '') },
          h('div', { class: 'mw-msg__bubble', html: escapeHtml(m.text || '').replace(/\n/g, '<br>') }),
          h('div', { class: 'mw-msg__meta' }, m.createdAt?.toMillis ? fmt.ago(m.createdAt.toMillis()) : ''),
        ));
      });
      msgs.scrollTop = msgs.scrollHeight;
    });

    async function send(e) {
      e.preventDefault();
      const text = e.target.text.value.trim();
      if (!text) return;
      e.target.text.value = '';
      try {
        const { db, sdk } = await fb();
        await sdk.db.addDoc(sdk.db.collection(db, COLLECTIONS.chats, chat.id, 'messages'), {
          from: me.uid, text, createdAt: sdk.db.serverTimestamp(),
        });
        await sdk.db.updateDoc(sdk.db.doc(db, COLLECTIONS.chats, chat.id), {
          lastMessage: text, updatedAt: sdk.db.serverTimestamp(),
        });
      } catch (err) { toast(err.message, { type: 'error' }); }
    }
  }

  return layout;
}
