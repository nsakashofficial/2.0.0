import { h, fmt } from '../utils/dom.js';
import { statCard } from '../components/cards.js';
import { store } from '../services/storage.js';
import { toast } from '../services/notification.js';
import { modal, confirm } from '../components/modal.js';

const KEYS = {
  methods: 'pay:methods',
  txns: 'pay:txns',
  earnings: 'pay:earnings',
};

// Seed reasonable defaults on first run — never hardcode real accounts.
if (!store.get(KEYS.earnings)) store.set(KEYS.earnings, { revenue: 0, pending: 0, paid: 0, premium: 0 });

export default async function view() {
  const root = h('section', { class: 'mw-view' }, h('div', { class: 'mw-container mw-pay' }));
  const wrap = root.querySelector('.mw-pay');
  render();

  function render() {
    const e = store.get(KEYS.earnings);
    const methods = store.get(KEYS.methods, []);
    const txns = store.get(KEYS.txns, []);
    wrap.innerHTML = '';
    wrap.append(
      h('header', { class: 'mw-pay__head' }, h('h1', {}, 'Payment center'),
        h('button', { class: 'mw-btn mw-btn--primary', onclick: withdraw }, 'Withdraw')),
      h('div', { class: 'mw-grid mw-grid--stats' },
        statCard({ label: 'Revenue', value: fmt.money(e.revenue) }),
        statCard({ label: 'Pending', value: fmt.money(e.pending) }),
        statCard({ label: 'Paid out', value: fmt.money(e.paid) }),
        statCard({ label: 'Premium', value: fmt.money(e.premium) }),
      ),
      h('section', { class: 'mw-card' },
        h('div', { class: 'mw-card__head' }, h('h3', {}, 'Payout methods'),
          h('button', { class: 'mw-btn mw-btn--ghost', onclick: () => addMethod(render) }, '+ Add')),
        methods.length ? h('ul', { class: 'mw-list' }, ...methods.map((m, i) => h('li', { class: 'mw-row' },
          h('span', {}, h('strong', {}, m.type.toUpperCase()), ' — ', maskLabel(m)),
          h('button', { class: 'mw-btn mw-btn--danger', onclick: async () => { if (await confirm({ title: 'Remove payout method?', destructive: true })) { const l = store.get(KEYS.methods, []); l.splice(i, 1); store.set(KEYS.methods, l); render(); } } }, 'Remove'))))
          : h('div', { class: 'mw-empty' }, 'No payout methods yet'),
      ),
      h('section', { class: 'mw-card' },
        h('div', { class: 'mw-card__head' }, h('h3', {}, 'Transactions'),
          h('button', { class: 'mw-btn mw-btn--ghost', onclick: exportCsv }, 'Export CSV')),
        txns.length ? h('table', { class: 'mw-table' },
          h('thead', {}, h('tr', {}, ...['Date','Type','Amount','Status'].map(t => h('th', {}, t)))),
          h('tbody', {}, ...txns.slice(0, 50).map(t => h('tr', {},
            h('td', {}, new Date(t.ts).toLocaleDateString()),
            h('td', {}, t.type),
            h('td', {}, fmt.money(t.amount)),
            h('td', {}, h('span', { class: 'mw-tag mw-tag--' + t.status }, t.status)),
          ))))
        : h('div', { class: 'mw-empty' }, 'No transactions yet'),
      ),
    );
  }

  function maskLabel(m) {
    if (m.type === 'bank') return `${m.bank || 'Bank'} •••• ${(m.number || '').slice(-4)}`;
    if (m.type === 'visa' || m.type === 'mastercard') return `•••• ${(m.number || '').slice(-4)}`;
    if (m.type === 'wallet') return m.address || 'Wallet';
    return m.label || '';
  }

  function exportCsv() {
    const rows = store.get(KEYS.txns, []);
    const csv = ['date,type,amount,status', ...rows.map(r => `${new Date(r.ts).toISOString()},${r.type},${r.amount},${r.status}`)].join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    a.download = `transactions-${Date.now()}.csv`; a.click();
    toast('Exported');
  }

  function withdraw() {
    const methods = store.get(KEYS.methods, []);
    if (!methods.length) return toast('Add a payout method first', { type: 'error' });
    const input = h('input', { class: 'mw-input', type: 'number', min: 1, step: '0.01', placeholder: 'Amount' });
    const sel = h('select', { class: 'mw-input' }, ...methods.map((m, i) => h('option', { value: i }, maskLabel(m))));
    modal({
      title: 'Withdraw funds',
      body: h('div', { class: 'mw-form' }, h('label', {}, 'Amount', input), h('label', {}, 'To', sel)),
      actions: [
        { label: 'Cancel', variant: 'ghost', onClick: c => c() },
        { label: 'Withdraw', variant: 'primary', onClick: (c) => {
          const amt = parseFloat(input.value); if (!amt || amt <= 0) return toast('Enter a valid amount', { type: 'error' });
          const e = store.get(KEYS.earnings); e.pending += amt; store.set(KEYS.earnings, e);
          const txns = store.get(KEYS.txns, []); txns.unshift({ ts: Date.now(), type: 'withdraw', amount: amt, status: 'pending' }); store.set(KEYS.txns, txns);
          toast('Withdrawal requested'); c(); render();
        }},
      ],
    });
  }
  return root;
}

export function addMethod(afterAdd) {
  const type = h('select', { class: 'mw-input' }, ...['bank','visa','mastercard','wallet'].map(t => h('option', { value: t }, t.toUpperCase())));
  const fields = h('div', { class: 'mw-form' });
  const render = () => {
    fields.innerHTML = '';
    const t = type.value;
    if (t === 'bank') fields.append(input('Bank name', 'bank'), input('Account holder', 'holder'), input('Account number', 'number'), input('SWIFT / IBAN', 'swift'));
    else if (t === 'wallet') fields.append(select('Wallet', 'wallet', ['PayPal','Wise','Crypto']), input('Wallet address / email', 'address'));
    else fields.append(input('Cardholder', 'holder'), input('Card number', 'number'), input('Expiry MM/YY', 'expiry'), input('CVV', 'cvv'));
  };
  type.addEventListener('change', render); render();
  modal({
    title: 'Add payout method',
    body: h('div', { class: 'mw-form' }, h('label', {}, 'Type', type), fields),
    actions: [
      { label: 'Cancel', variant: 'ghost', onClick: c => c() },
      { label: 'Save', variant: 'primary', onClick: (c) => {
        const m = { type: type.value };
        fields.querySelectorAll('[data-key]').forEach(i => m[i.dataset.key] = i.value);
        const l = store.get(KEYS.methods, []); l.push(m); store.set(KEYS.methods, l);
        toast('Payout method saved'); c(); afterAdd?.();
      }},
    ],
  });
}
function input(label, key) { return h('label', {}, label, h('input', { class: 'mw-input', 'data-key': key })); }
function select(label, key, opts) { return h('label', {}, label, h('select', { class: 'mw-input', 'data-key': key }, ...opts.map(o => h('option', {}, o)))); }
