import { h } from '../utils/dom.js';
import { toggleTheme, currentTheme } from '../utils/theme.js';
import { navigate } from '../utils/router.js';

/** Top navbar: centered logo, right-side icons (messenger + theme + profile). */
export function navbar({ user }) {
  const el = h('header', { class: 'mw-nav' },
    h('button', { class: 'mw-nav__icon', 'aria-label': 'Search', onclick: () => navigate('/search') }, iconSearch()),
    h('a', { class: 'mw-nav__brand', href: '#/', 'aria-label': 'Meetwoyou home' },
      h('span', { class: 'mw-brand__logo' }, 'M'),
      h('span', { class: 'mw-brand__word' }, 'Meetwoyou'),
    ),
    h('div', { class: 'mw-nav__actions' },
      h('button', { class: 'mw-nav__icon', 'aria-label': 'Messenger', onclick: () => navigate('/messenger') },
        iconMsg(), user?.unread ? h('span', { class: 'mw-badge-dot' }) : null,
      ),
      h('button', { class: 'mw-nav__icon', 'aria-label': 'Toggle theme', onclick: () => { toggleTheme(); } },
        currentTheme() === 'dark' ? iconSun() : iconMoon(),
      ),
      h('button', { class: 'mw-nav__avatar', 'aria-label': 'Profile', onclick: () => navigate('/profile') },
        user?.photoURL ? h('img', { src: user.photoURL, alt: '' }) : h('span', {}, (user?.email || '?')[0].toUpperCase()),
      ),
    ),
  );
  return el;
}

/** Mobile bottom tab bar. Uses only plus (no duplicate post). */
export function tabbar() {
  const items = [
    ['/', 'Home', iconHome()],
    ['/search', 'Search', iconSearch()],
    ['/create', '', iconPlus(), 'mw-tab__plus'],
    ['/messenger', 'Chat', iconMsg()],
    ['/profile', 'Me', iconUser()],
  ];
  return h('nav', { class: 'mw-tabbar', 'aria-label': 'Primary' },
    ...items.map(([path, label, ic, extra]) => h('a', {
      class: 'mw-tab ' + (extra || ''),
      href: '#' + path,
      'aria-label': label || 'Create',
    }, ic, label ? h('span', {}, label) : null))
  );
}

function svg(d, extra = '') {
  const t = document.createElement('template');
  t.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" ${extra}>${d}</svg>`;
  return t.content.firstChild;
}
export const iconHome = () => svg('<path d="M3 11 12 3l9 8v9a2 2 0 0 1-2 2h-4v-6H9v6H5a2 2 0 0 1-2-2z"/>');
export const iconSearch = () => svg('<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>');
export const iconMsg = () => svg('<path d="M21 12a8 8 0 0 1-11.7 7.1L4 21l1.9-5.3A8 8 0 1 1 21 12z"/>');
export const iconUser = () => svg('<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>');
export const iconPlus = () => svg('<path d="M12 5v14M5 12h14"/>');
export const iconMoon = () => svg('<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>');
export const iconSun = () => svg('<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>');
