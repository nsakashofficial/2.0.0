import { h } from '../utils/dom.js';

/** Tiered verified badge — blue / gold / diamond. Elegant, animated. */
export function verifiedBadge(tier = 'blue', { size = 16 } = {}) {
  const t = ['blue', 'gold', 'diamond'].includes(tier) ? tier : 'blue';
  const tpl = document.createElement('template');
  tpl.innerHTML = `<span class="mw-badge mw-badge--${t}" role="img" aria-label="${t} verified" style="--sz:${size}px">
    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2 15 4l3-.5L19 6l2.5 2L21 11l1 3-2 2-.5 3-3 1-2 2-3-1-3 1-2-2-3-1L3 15l-1-3 1-3-.5-3L5 4l2.5 2L11 4z"/><path class="mw-badge__tick" d="m8 12 3 3 5-6" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
  </span>`;
  return tpl.content.firstChild;
}

export function tagBadge(label, tone = 'default') {
  return h('span', { class: `mw-tag mw-tag--${tone}` }, label);
}
