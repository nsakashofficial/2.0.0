import { h } from '../utils/dom.js';

export function modal({ title, body, actions = [], onClose } = {}) {
  const close = () => { root.classList.remove('is-open'); setTimeout(() => root.remove(), 200); onClose?.(); };
  const root = h('div', { class: 'mw-modal', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'mw-modal-title' },
    h('div', { class: 'mw-modal__backdrop', onclick: close }),
    h('div', { class: 'mw-modal__panel' },
      h('header', { class: 'mw-modal__head' },
        h('h3', { id: 'mw-modal-title' }, title || ''),
        h('button', { class: 'mw-modal__x', 'aria-label': 'Close', onclick: close }, '×'),
      ),
      h('div', { class: 'mw-modal__body' }, body || ''),
      actions.length ? h('footer', { class: 'mw-modal__foot' },
        ...actions.map(a => h('button', { class: `mw-btn ${a.variant ? 'mw-btn--' + a.variant : ''}`, onclick: () => a.onClick?.(close) }, a.label))
      ) : null,
    ),
  );
  document.body.appendChild(root);
  requestAnimationFrame(() => root.classList.add('is-open'));
  document.addEventListener('keydown', function esc(e) { if (e.key === 'Escape') { close(); document.removeEventListener('keydown', esc); } });
  return { close };
}

export function bottomSheet({ title, body, onClose } = {}) {
  const close = () => { root.classList.remove('is-open'); setTimeout(() => root.remove(), 250); onClose?.(); };
  const root = h('div', { class: 'mw-sheet', role: 'dialog', 'aria-modal': 'true' },
    h('div', { class: 'mw-sheet__backdrop', onclick: close }),
    h('div', { class: 'mw-sheet__panel' },
      h('div', { class: 'mw-sheet__grip' }),
      title ? h('h3', { class: 'mw-sheet__title' }, title) : null,
      h('div', { class: 'mw-sheet__body' }, body || ''),
    ),
  );
  document.body.appendChild(root);
  requestAnimationFrame(() => root.classList.add('is-open'));
  return { close };
}

export function confirm({ title = 'Are you sure?', message = '', confirmLabel = 'Confirm', destructive = false } = {}) {
  return new Promise((res) => {
    modal({
      title,
      body: h('p', { class: 'mw-modal__msg' }, message),
      actions: [
        { label: 'Cancel', variant: 'ghost', onClick: (c) => { c(); res(false); } },
        { label: confirmLabel, variant: destructive ? 'danger' : 'primary', onClick: (c) => { c(); res(true); } },
      ],
    });
  });
}
