import { h, fmt, escapeHtml } from '../utils/dom.js';
import { verifiedBadge } from './badge.js';

export function postCard(post) {
  const author = post.author || { name: 'User' };
  const article = h('article', { class: 'mw-card mw-post' },
    h('header', { class: 'mw-post__head' },
      h('div', { class: 'mw-post__avatar' }, author.photoURL ? h('img', { src: author.photoURL, alt: '' }) : h('span', {}, (author.name || '?')[0])),
      h('div', { class: 'mw-post__meta' },
        h('div', { class: 'mw-post__author' }, author.name || 'User', author.verified ? verifiedBadge(author.verified) : null),
        h('div', { class: 'mw-post__time' }, post.createdAt ? fmt.ago(post.createdAt) : ''),
      ),
    ),
    post.text ? h('p', { class: 'mw-post__text', html: escapeHtml(post.text).replace(/\n/g, '<br>') }) : null,
    post.image ? h('img', { class: 'mw-post__media', src: post.image, loading: 'lazy', alt: '' }) : null,
    h('footer', { class: 'mw-post__foot' },
      h('button', { class: 'mw-post__action', 'aria-label': 'Like' }, '♥ ', h('span', {}, fmt.n(post.likes || 0))),
      h('button', { class: 'mw-post__action', 'aria-label': 'Comment' }, '💬 ', h('span', {}, fmt.n(post.comments || 0))),
      h('button', { class: 'mw-post__action', 'aria-label': 'Share' }, '↗'),
    ),
  );
  return article;
}

export function statCard({ label, value, delta, hint }) {
  return h('div', { class: 'mw-card mw-stat' },
    h('div', { class: 'mw-stat__label' }, label),
    h('div', { class: 'mw-stat__value' }, typeof value === 'number' ? fmt.n(value) : value),
    delta != null ? h('div', { class: 'mw-stat__delta ' + (delta >= 0 ? 'is-up' : 'is-down') }, (delta >= 0 ? '▲ ' : '▼ ') + Math.abs(delta) + '%') : null,
    hint ? h('div', { class: 'mw-stat__hint' }, hint) : null,
  );
}

export function chatCard(chat, onOpen) {
  return h('button', { class: 'mw-card mw-chat', onclick: () => onOpen?.(chat) },
    h('div', { class: 'mw-chat__avatar' }, chat.photoURL ? h('img', { src: chat.photoURL, alt: '' }) : h('span', {}, (chat.name || '?')[0])),
    h('div', { class: 'mw-chat__body' },
      h('div', { class: 'mw-chat__row' },
        h('span', { class: 'mw-chat__name' }, chat.name || 'Chat'),
        h('span', { class: 'mw-chat__time' }, chat.lastAt ? fmt.ago(chat.lastAt) : ''),
      ),
      h('div', { class: 'mw-chat__row' },
        h('span', { class: 'mw-chat__preview' }, chat.typing ? 'Typing…' : (chat.lastMsg || '')),
        chat.unread ? h('span', { class: 'mw-chat__unread' }, String(chat.unread)) : null,
      ),
    ),
  );
}
