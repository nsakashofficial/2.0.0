import { h } from '../utils/dom.js';

export function button({ label, variant = 'primary', icon, onClick, type = 'button', disabled = false } = {}) {
  return h('button', {
    class: `mw-btn mw-btn--${variant}`,
    type, disabled, onclick: onClick,
  }, icon || null, label);
}

export function iconButton({ label, icon, onClick } = {}) {
  return h('button', { class: 'mw-iconbtn', 'aria-label': label, onclick: onClick }, icon);
}
