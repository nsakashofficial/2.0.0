/**
 * Runtime environment overrides for Meetwoyou.
 * Assign values here at deploy time to override .env.example defaults.
 * Leave empty to use the existing production Firebase/Cloudinary config.
 */
window.__MW_ENV__ = {
  // FIREBASE_API_KEY: '',
  // FIREBASE_AUTH_DOMAIN: '',
  // FIREBASE_PROJECT_ID: '',
  // FIREBASE_STORAGE_BUCKET: '',
  // FIREBASE_MESSAGING_SENDER_ID: '',
  // FIREBASE_APP_ID: '',
  // CLOUDINARY_CLOUD_NAME: '',
  // CLOUDINARY_UPLOAD_PRESET: '',
};
