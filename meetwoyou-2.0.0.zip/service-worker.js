/* Meetwoyou service worker — offline-first for app shell, network-first for API. */
const VERSION = 'v2.0.0';
const SHELL_CACHE = `mw-shell-${VERSION}`;
const RUNTIME_CACHE = `mw-runtime-${VERSION}`;

const SHELL = [
  './',
  './index.html',
  './manifest.webmanifest',
  './css/main.css',
  './css/tokens.css',
  './css/base.css',
  './css/components.css',
  './js/main.js',
  './js/utils/dom.js',
  './js/utils/router.js',
  './js/utils/theme.js',
  './js/utils/i18n.js',
  './js/services/config.js',
  './js/services/firebase.js',
  './js/services/cloudinary.js',
  './js/services/storage.js',
  './js/services/notification.js',
  './js/services/auth.js',
  './js/components/navbar.js',
  './js/components/modal.js',
  './js/components/cards.js',
  './js/components/buttons.js',
  './js/components/badge.js',
  './assets/icons/favicon-192x192.png',
  './assets/icons/favicon-512x512.png',
  './pages/offline.html',
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(SHELL_CACHE).then(c => c.addAll(SHELL).catch(() => {})).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(k => ![SHELL_CACHE, RUNTIME_CACHE].includes(k)).map(k => caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener('message', (e) => { if (e.data === 'SKIP_WAITING') self.skipWaiting(); });

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // Navigation → app shell (SPA)
  if (req.mode === 'navigate') {
    e.respondWith(fetch(req).catch(async () => (await caches.match('./index.html')) || (await caches.match('./pages/offline.html'))));
    return;
  }

  // Google APIs (Firestore, Auth) → network-first
  if (/googleapis|gstatic|firebaseio/.test(url.hostname)) {
    e.respondWith(fetch(req).catch(() => caches.match(req)));
    return;
  }

  // Cloudinary media → cache-first with runtime cache
  if (/res\.cloudinary\.com|cloudinary/.test(url.hostname)) {
    e.respondWith(caches.open(RUNTIME_CACHE).then(async cache => {
      const hit = await cache.match(req); if (hit) return hit;
      try { const res = await fetch(req); if (res.ok) cache.put(req, res.clone()); return res; }
      catch { return hit || Response.error(); }
    }));
    return;
  }

  // Same-origin: stale-while-revalidate
  if (url.origin === location.origin) {
    e.respondWith(caches.match(req).then(hit => {
      const fetching = fetch(req).then(res => {
        if (res && res.ok) caches.open(SHELL_CACHE).then(c => c.put(req, res.clone()));
        return res;
      }).catch(() => hit);
      return hit || fetching;
    }));
  }
});

// Background sync outbox
self.addEventListener('sync', (e) => {
  if (e.tag === 'mw-outbox') e.waitUntil(flushOutbox());
});
async function flushOutbox() { /* Consumer app posts through IndexedDB; extend as needed. */ }

// Push
self.addEventListener('push', (e) => {
  const data = (() => { try { return e.data?.json() || {}; } catch { return { title: 'Meetwoyou', body: e.data?.text() || '' }; } })();
  e.waitUntil(self.registration.showNotification(data.title || 'Meetwoyou', {
    body: data.body || '',
    icon: './assets/icons/favicon-192x192.png',
    badge: './assets/icons/favicon-192x192.png',
    data: data.url || './',
  }));
});
self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  e.waitUntil(clients.openWindow(e.notification.data || './'));
});
